// import './1_Functions/1_RestAndSpread';
// import './1_Functions/2_PureAndImpureFn';
// import './1_Functions/3_FunctionOverloading';
// import './1_Functions/4_IIFE';
// import './1_Functions/5_OverloadingAssignment';
// import './1_Functions/6_ArrowFunctions';
// import './1_Functions/7_FnAsParameter';
// import './1_Functions/8_Closure';
// import './1_Functions/9_Context';
import './1_Functions/10_Currying';


// import './2_Types/1_ObjectCreation';