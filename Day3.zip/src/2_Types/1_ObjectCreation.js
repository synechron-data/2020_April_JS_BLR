// var obj = null;
// console.log(obj);
// console.log(typeof obj);

// var obj1 = new Object();
// console.log(obj1);
// console.log(typeof obj1);

// var obj2 = {};
// console.log(obj2);
// console.log(typeof obj2);

var person = {
    id: 1,
    name: "Manish",
    address: {
        city: "Pune"
    },
    display: function () {
        console.log(this);
    }
};

// person.display();

console.log(person);
console.log(JSON.stringify(person));