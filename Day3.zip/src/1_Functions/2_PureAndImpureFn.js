// // ----------------------------- With Primitive

// var a = 1;

// function modify(data){
//     data = 100;
// }

// console.log("Before - ", a);
// modify(a);
// console.log("After - ", a);

// ----------------------------- With Complex

// var a = [10, 20, 30];

// function modify(data) {
//     data.push(100);
// }

// console.log("Before - ", a);
// modify(a);
// console.log("After - ", a);

// var a = [10, 20, 30];

//Impure Function
// function insert(dataArr, x){
//     dataArr[dataArr.length] = x;
//     return dataArr;
// } 

// Pure Function
// function insert(dataArr, x) {
//     var rArr = [...dataArr];
//     rArr[dataArr.length] = x;
//     return rArr;
// }

// var newArr1 = insert(a, 100);       // Expected - [10, 20, 30, 100]
// var newArr2 = insert(a, 200);       // Expected - [10, 20, 30, 200]

// console.log(newArr1);
// console.log(newArr2);

// -----------------------------------------------------

var employees = ["Akshay", "Basavaraj", "Bhavya", "Bibhu", "Chethan", "Chhavi"];

function filter(dataArr, x) {
    var result = [];

    for (let i = 0; i < dataArr.length; i++) {
        if (dataArr[i].startsWith(x))
            result.push(dataArr[i]);
    }

    return [...result];
}

var result1 = filter(employees, 'A');
console.log(result1);

var result2 = filter(employees, 'B');
console.log(result2);

var result3 = filter(employees, 'C');
console.log(result3);