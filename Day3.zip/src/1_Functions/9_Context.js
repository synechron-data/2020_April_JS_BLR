// function Test() {
//     console.log(this);
// }

// Test();
// Test.call();
// Test.apply();

// var p1 = {
//     id: 1,
//     test: function () {
//         console.log(this);
//     }
// }

// p1.test();

// Test();
// Test.call(p1);
// Test.apply(p1);

// p1.test();
// p1.test.call(window);

// function Check(x, y) {
//     console.log(this);
//     console.log(`x= ${x}, y = ${y}`);
// }

// Check(2, 3);
// Check.call(p1, 2, 3);
// Check.apply(p1, [2, 3]);

// ------------------------------------------------------------------

// var p1 = {
//     id: 1,
//     name: "Manish",
//     display: function () {
//         console.log(JSON.stringify(this));
//     }
// };

// var p2 = {
//     id: 2,
//     name: "Abhijeet",
//     display: function () {
//         console.log(JSON.stringify(this));
//     }
// };

// p1.display();
// p2.display();

function display() {
    console.log(JSON.stringify(this));
}

var p1 = {
    id: 1,
    name: "Manish"
};

var p2 = {
    id: 2,
    name: "Abhijeet"
};

p1.display = display.bind(p1);
p2.display = display.bind(p2);

p1.display();
p2.display();