// var arr = [10, 20, 30, 40, 50, 60, 70, 80, 90];

// var [x, , y] = arr;
// console.log(`Before Swap, x = ${x}, y = ${y}`);

// [x, y] = [y, x];

// console.log(`After Swap, x = ${x}, y = ${y}`);

// ------------------------------------------------------- ES 2018 (Object Rest and Spread)

// var p1 = { id: 1, name: "Manish", city: "Pune", state: "MH" };

// var id = p1.id;
// var name = p1.name;

// var { id, name } = p1;

// console.log("Id ", id);
// console.log("Name ", name);

// var p2 = p1;

// Shallow Copy
// var p2 = Object.assign({}, p1); // New Method of ES 2015
// var p2 = { ...p1 };

// p2.name = "Abhijeet";

// console.log("P1 - ", p1);
// console.log("P2 - ", p2);

// Object Rest
// var p1 = { id: 1, name: "Manish", city: "Pune", state: "MH" };
// var { id, name, ...address } = p1;

// console.log("Id ", id);
// console.log("Name ", name);
// console.log("Address ", address);

// Shallow Vs Deep Copy
var p1 = { id: 1, name: "Manish", address: { city: "Pune", state: "MH" } };

// var p2 = p1;            // Refrence Copy

// Shallow Copy
// var p2 = Object.assign({}, p1);
// var p2 = { ...p1 };

// Deep Copy
var p2 = JSON.parse(JSON.stringify(p1));

p2.name = "Abhijeet";
p2.address.city = "Mumbai";

console.log("P1 - ", p1);
console.log("P2 - ", p2);

// Third Party Library, which can be used for deep copying
// lodash
// Ramda
// rfdc (It is the fastest Deep Copy Library)
// Immutability-helper (Copy with Functions)
// Immutable.js - programatically enforce immutability