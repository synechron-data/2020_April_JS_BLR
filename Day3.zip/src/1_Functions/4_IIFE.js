// function hello() {
//     console.log("Hello World!");
// }

// hello();

// Immediatly Invoked Function Expression (IIFE)

(function () {
    console.log("Hello World!");
}());

(function () {
    console.log("Hello World!");
})();

(function (name) {
    console.log("Hello,", name);
}("Abhijeet"));

(function (name) {
    console.log("Hello,", name);
})("Manish");