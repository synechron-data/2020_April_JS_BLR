// document.getElementById("b1").addEventListener("click", function(e){

// })

// $(document).ready(function () {
//     $("#b1").click(function () {

//     })
// });

// var i = 0;
// setInterval(function () {
//     console.log(i++);
// }, 2000);

// // --------------------------------------------------------- Pull

// // Dev 1

// function getString() {
//     const strArr = ['NodeJS', 'ReactJS', 'AngularJS', 'ExtJS', 'VueJS'];
//     var str = strArr[Math.floor(Math.random() * strArr.length)];
//     return str;
// }

// // Dev 2

// setInterval(function () {
//     var s = getString();
//     console.log(s);
// }, 2000);

// --------------------------------------------------------- Push

// Dev 1

function getString(done) {
    const strArr = ['NodeJS', 'ReactJS', 'AngularJS', 'ExtJS', 'VueJS'];
    setInterval(() => {
        var str = strArr[Math.floor(Math.random() * strArr.length)];
        done(str);
    }, 2000);
}

// Dev 2

// getString(function (s) {
//     console.log(s);
// });

getString(s => {
    console.log(s);
});