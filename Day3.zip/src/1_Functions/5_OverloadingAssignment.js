// const Add = (function () {
//     function m1(a, b) {
//         return a + b;
//     }

//     function m2(a, b, c) {
//         return a + b + c;
//     }

//     return function () {
//         if (arguments.length == 2)
//             return m1(arguments[0], arguments[1]);
//         else if (arguments.length == 3)
//             return m2(arguments[0], arguments[1], arguments[2]);
//         else
//             throw Error("Invalid Parameters....");
//     }
// })();

function Add(...args) {
    if (arguments.length == 2)
        return args[0] + args[1];
    else if (arguments.length == 3)
        return args[0] + args[1] + args[2];
    else
        throw Error("Invalid Parameters....");
}

console.log(Add(2, 3));
console.log(Add(2, 3, 4));
// console.log(Add(2));        // Show Error, if you are passing less than 2 or more than 3 arguments
// console.log(Add(2, 3, 4, 5));