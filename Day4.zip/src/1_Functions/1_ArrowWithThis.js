// What is the diff. between Function Constructor & Constructor Function?
// Function Constructor
// const hello = new Function('console.log("Hello World")');
// hello();

// Constructor Function
// function Person() {
//     // var id = 1;
//     this.age = 20;

//     this.growOld = function () {
//         console.log(this);
//         this.age += 1;
//     }
// }

// var p1 = new Person();
// console.log(p1.id);
// console.log(p1.age);
// p1.growOld();
// p1.growOld();
// p1.growOld();
// p1.growOld();
// console.log(p1.age);

// // -------------------------------------------

// setInterval(p1.growOld, 1000);

// setInterval(function(){
//     console.log(p1.age);
// }, 1000);

// -------------------------------------------

// setInterval(p1.growOld.bind(p1), 1000);

// setInterval(function(){
//     console.log(p1.age);
// }, 1000);

// ---------------------------------------------------------- Lexical Closure
// function Person() {
//     var self = this;
//     self.age = 20;

//     self.growOld = function () {
//         self.age += 1;
//     }
// }

// var p1 = new Person();

// setInterval(p1.growOld, 1000);

// setInterval(function(){
//     console.log(p1.age);
// }, 1000);

// In ES5 ‘this’ refers to the parent of the function and the object through which the function was called

// ------------------------------------------------------------- Arrow & this

// function hello1() {
//     console.log(this);
// }

// hello1();

// const hello2 = function () {
//     console.log(this);
// }

// hello2();

// const hello3 = () => {
//     console.log(this);
// }

// hello3();

function Person() {
    this.age = 20;

    this.growOld = () => {
        this.age += 1;
    }
}

var p1 = new Person();

setInterval(p1.growOld, 1000);

setInterval(function(){
    console.log(p1.age);
}, 1000);

// In ES6, arrow functions use lexical scoping — ‘this’ refers to it’s current surrounding scope and no further.