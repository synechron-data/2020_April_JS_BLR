// let source = { id: 1, name: "Manish", address: { city: "Pune" } };
// let target = { lastname: "Sharma" };

// let obj1 = Object.assign({}, source);
// console.log(obj1);

// let obj2 = Object.assign(target, source);
// console.log(obj2);

// console.log(target);
// console.log(obj2 === target);

// -------------------------------------------- Object.create
// Creates a new object, using an existing object as the prototype of the newly created object.
// let source = { id: 1, name: "Manish", address: { city: "Pune" } };

// let newSource1 = Object.assign({}, source);
// let newSource2 = Object.create(source);

// console.log(newSource1);
// console.log(newSource2);

// --------------------------------------------
// let source = { id: 1, name: "Manish" };

// Object.preventExtensions(source);
// if (Object.isExtensible(source)) {
//     source.city = "Pune";
//     console.log(source);
// }

// Object.freeze(source);
// if (!Object.isFrozen(source)) {
//     source.id = 10000;
//     source.city = "Pune";
//     console.log(source);
// }

// Object.seal(source);

// if (!Object.isSealed(source)) {
//     delete source.id;
//     source.city = "Pune";
//     console.log(source);
// }

// --------------------------------------------

// function Test(){

// }

// // console.log(Test.prototype);
// var o = new Test();
// // console.log(o);
// console.log(Object.getPrototypeOf(o));

// Object.setPrototypeOf(o, new Object());
// console.log(Object.getPrototypeOf(o));


// -------------------------------------------------

let source = { id: 1, name: "Manish" };
let newSource = Object.create(source);

// console.log(newSource);
// for (const key in source) {
//     console.log(key);
// }

// for (const key in newSource) {
//     console.log(key);
// }

// Object.keys(source).forEach((key) => {
//     console.log(key);
// });

// Object.keys(newSource).forEach((key) => {
//     console.log(key);
// });