// var employees = new Array();
// var employees = new Array(2);
// var employees = Array.from([1, 2, 3, 4, 5]);
// var employees = new Array('abc');
// var employees = [];
// var employees = Array.of(2, 3, 4, 5);

// console.log(employees);
// console.log(employees.length);
// console.log(typeof employees);

// var employees = new Array(2);
// console.log(`Length of Employees ${employees.length}`);

// // employees[0] = "Manish";
// // employees[1] = "Abhijeet";
// // employees[2] = "Pravin";
// // employees[5] = "Ramakant";

// employees.unshift("Manish");
// // employees.push("Manish");
// employees.push("Abhijeet");
// employees.push("Pravin");
// employees.push("Ramakant");

// console.log(`Length of Employees ${employees.length}`);
// console.log(employees);

// var employees = [
//     { id: 1, name: "Manish" },
//     { id: 2, name: "Varun" },
//     { id: 3, name: "Paresh" },
//     { id: 4, name: "Devesh" },
//     { id: 5, name: "Atul" },
// ];

// for (let i = 0; i < employees.length; i++) {
//     console.log(`${i}   ${JSON.stringify(employees[i])}`);
// }

// employees.forEach((item, index, arr)=>{
//     console.log(`${index}   ${JSON.stringify(item)}`);
// });

// for (const item of employees) {
//     console.log(`${JSON.stringify(item)}`);
// }

// for (const [index, item] of employees.entries()) {
//     console.log(`${index}   ${JSON.stringify(item)}`);
// }

// Associative Arrays

// var states = new Array();

// states["GA"] = "Goa";
// states["DL"] = "Delhi";
// states["MH"] = "Maharashtra";

// for(const key in states){
//     console.log(`${key}     ${states[key]}`);
// }