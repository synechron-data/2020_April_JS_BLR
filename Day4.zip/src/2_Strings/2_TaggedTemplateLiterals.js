const name = 'Rex';
const age = '4';

// const sentence = "My pet's name is " + name + " and he is " + age + " months old";

// Template Literals
// const sentence = `My pet's name is ${name} and he is ${age} months old`;
// console.log(sentence);

function generate(strings, ...values) {
    // console.log(strings);
    // console.log(values);
    // return "Hello";

    let str = '';
    strings.forEach((string, i) => {
        str += `${string} <span class="hl">${values[i] || ''}</span>`
    });
    return `<h2>${str}</h2>`;
}

const html = generate`My pet's name is ${name} and he is ${age} months old`;

// DOM Manipulation (HTML5 API's)
const root = document.querySelector('.root');
root.innerHTML = html;
