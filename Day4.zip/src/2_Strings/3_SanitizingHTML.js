import DOMPurify from 'dompurify';

const header = "Sanitizing HTML using Tagged Template Literals";

function sanitize(strings, ...values) {
    const dirty = strings.reduce((prev, next, i) => `${prev}${next}${values[i] || ''}`);
    return DOMPurify.sanitize(dirty);
}

const image = sanitize`This is an image <img src="http://unsplash.it/100/100?random" onload="alert('You got attacked by XSS')"/>`;

const html = `<h2>${header}</h2>
                ${image}`;

const root = document.querySelector('.root');
root.innerHTML = html;