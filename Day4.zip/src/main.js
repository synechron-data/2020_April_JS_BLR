// import './1_Functions/1_ArrowWithThis';

// import './2_Strings/1_StringMethods';
// import './2_Strings/2_TaggedTemplateLiterals';
// import './2_Strings/3_SanitizingHTML';

// import './3_Collections/1_Arrays';
// import './3_Collections/2_Map';
// import './3_Collections/3_Set';

// import './4_Modules/usage';

// import './5_Types/1_ObjectType';
import './5_Types/2_ObjectMethods';


