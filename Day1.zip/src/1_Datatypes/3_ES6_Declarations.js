// Block Scope

// let a = 10;
// console.log(a);
// console.log(typeof a);

// Hoisting - Hoisting is JavaScript's default behavior of moving declarations to the top.
// let keyword is not hoisted
// a = 10;
// console.log(a);
// let a;

// let a = 10;
// let a = "Hello";
// console.log(a);

// ------------------------------------------------

const env = "devlopment";
console.log(env);
console.log(typeof env);

env = "production";
console.log(env);
