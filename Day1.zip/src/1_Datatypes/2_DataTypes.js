// var language;
// console.log("Language is: ", language);
// console.log("Language is: ", typeof language);

// language = null;
// console.log("Language is: ", language);
// console.log("Language is: ", typeof language);

// // language = 10;
// language = 10.5;
// console.log("Language is: ", language);
// console.log("Language is: ", typeof language);

// language = "JavaScript";
// // language = 'JavaScript';
// // language = '"JavaScript"';

// // ES 2015 - Template Literal
// // language = `Java

// // Script`;

// console.log("Language is: ", language);
// console.log("Language is: ", typeof language);

// language = true;
// console.log("Language is: ", language);
// console.log("Language is: ", typeof language);

// // ES 2015 - Symbol
// language = Symbol("hello");
// console.log("Language is: ", language);
// console.log("Language is: ", typeof language);

// // language = String("JavaScript");
// // console.log("Language is: ", language);
// // console.log("Language is: ", typeof language);

// // language = new String("JavaScript");
// // console.log("Language is: ", language);
// // console.log("Language is: ", typeof language);

var i = 10;
var j = i;

i = 20;

console.log(i);
console.log(j);