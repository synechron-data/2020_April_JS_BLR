// ES 5 - Scopes
// Global Scope
// Function Scope (Local Scope)


// ECMASCRIPT 2015 - Scopes
// Global Scope
// Function Scope (Local Scope)
// Block Scope (let or const keyword)

// -------------------------------------------------------
// var i = "Hello";
// console.log("Before, i is", i);

// for (var i = 0; i < 5; i++) {
//     console.log("Inside Loop, i is", i);
// }

// console.log("After, i is", i);


// --------------------------------------------------------
// var i = "Hello";
// console.log("Before, i is", i);

// function loop(){
//     for (var i = 0; i < 5; i++) {
//         console.log("Inside Loop, i is", i);
//     }
// }

// loop();

// console.log("After, i is", i);

// ------------------------------------------------------- Block Scoping
var i = "Hello";
console.log("Before, i is", i);

for (let i = 0; i < 5; i++) {
    console.log("Inside Loop, i is", i);
}

console.log("After, i is", i);
