'use strict'
// console.log("Hello from Declarations File....");

// a = 10;
// console.log(a);

// var a;
// a = 10;
// console.log(a);

// var b = 20;
// console.log(b);

// Hoisting - Hoisting is JavaScript's default behavior of moving declarations to the top.
// a = 10;
// console.log(a);
// var a;

// Definitions or Initializations are not hoisted
// console.log(a);
// var a = 10;

// Runtime will see the below code
// var a;
// console.log(a);
// a = 10;

// var a = 10;
// a = "Manish";
// a = true;
// a = new Object();

// console.log(a);

var a = 10;
var a = "Hello";
console.log(a);
