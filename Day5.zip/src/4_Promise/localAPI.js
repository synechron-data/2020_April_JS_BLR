const localAPI = {
    getAllPosts: function (successCB, errorCB) {
        fetch('https://jsonplaceholder.typicode.com/posts').then((response) => {
            response.json().then(data => {
                successCB(data);
            }).catch(err => {
                errorCB("Parsing Error");
            })
        }).catch((err) => {
            errorCB("Communication Error");
        });
    },

    getAllPostsUsingPromise: function () {
        var promise = new Promise((resolve, reject)=>{
            fetch('https://jsonplaceholder.typicode.com/posts').then((response) => {
                response.json().then(data => {
                    resolve(data);
                }).catch(err => {
                    reject("Parsing Error");
                })
            }).catch((err) => {
                reject("Communication Error");
            });
        });

        return promise;
    },

    getPosts: function () {
        var promise = new Promise((resolve, reject)=>{
            fetch('https://ajsonplaceholder.typicode.com/posts').then((response) => {
                response.json().then(data => {
                    resolve(data);
                }).catch(err => {
                    reject("Parsing Error");
                })
            }).catch((err) => {
                reject("Communication Error");
            });
        });

        return promise;
    }
};

export default localAPI;