import localAPI from './localAPI';

document.getElementById("btnJS").addEventListener("click", async () => {
    try {
        var result = await localAPI.getPosts();
        console.log(result);
    } catch (e) {
        console.error(e);
    }
});

// document.getElementById("btnJS").addEventListener("click", () => {
//     localAPI.getAllPostsUsingPromise().then((data) => {
//         console.log(data);
//     }, (msg) => {
//         console.error(msg);
//     });
// });

// document.getElementById("btnJS").addEventListener("click", function () {
//     localAPI.getAllPosts((data) => {
//         console.log(data);
//     }, (msg) => {
//         console.error(msg);
//     });
// });

// document.getElementById("btnJS").addEventListener("click", function () {
//     fetch('https://jsonplaceholder.typicode.com/posts').then((response) => {
//         // console.log(response);
//         response.json().then(data => { 
//             console.log(data);
//         }).catch(err => {
//             console.error("Parsing Error");
//         })
//     }).catch((err) => {
//         console.error("Communication Error");
//     });
// });

// document.getElementById("btnJS").addEventListener("click", function () {
//     alert("Button was clicked....");
// });