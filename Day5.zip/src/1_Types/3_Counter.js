// function getCounter(interval = 1) {
//     var count = 0;

//     return {
//         next: function () {
//             return count += interval;
//         },
//         prev: function () {
//             return count -= interval;
//         }
//     };
// }

const Counter = (function () {
    function Counter(interval = 1) {
        this._count = 0;
        this._interval = interval;
    }

    Counter.prototype.next = function () {
        return this._count += this._interval;
    }

    Counter.prototype.prev = function () {
        return this._count -= this._interval;
    }

    return Counter;
})();

var counter = new Counter();
console.log(counter.next());
console.log(counter.next());
console.log(counter.prev());

console.log("\n");
var counter5 = new Counter(5);
console.log(counter5.next());
console.log(counter5.next());
console.log(counter5.prev());

console.log(counter);
console.log(counter5);