class Counter {
    constructor(interval = 1) {
        this._count = 0;
        this._interval = interval;
    }

    next() {
        return this._count += this._interval;
    }

    prev() {
        return this._count -= this._interval;
    }
}

var counter = new Counter();
console.log(counter.next());
console.log(counter.next());
console.log(counter.prev());

console.log("\n");
var counter5 = new Counter(5);
console.log(counter5.next());
console.log(counter5.next());
console.log(counter5.prev());

console.log(counter);
console.log(counter5);