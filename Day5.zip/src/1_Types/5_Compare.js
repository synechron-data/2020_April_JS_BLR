function CL_Counter(interval = 1) {
    var count = 0;

    return {
        next: function () {
            return count += interval;
        },
        prev: function () {
            return count -= interval;
        }
    };
}

function CFN_Counter(interval = 1) {
    this._count = 0;
    this._interval = interval;

    this.next = function () {
        return this._count += this._interval;
    }

    this.prev = function () {
        return this._count -= this._interval;
    }
}

const PT_Counter = (function () {
    function Counter(interval = 1) {
        this._count = 0;
        this._interval = interval;
    }

    Counter.prototype.next = function () {
        return this._count += this._interval;
    }

    Counter.prototype.prev = function () {
        return this._count -= this._interval;
    }

    return Counter;
})();

class Counter {
    constructor(interval = 1) {
        this._count = 0;
        this._interval = interval;
    }

    next() {
        return this._count += this._interval;
    }

    prev() {
        return this._count -= this._interval;
    }
}

(function(){
    var clStTime = new Date();
    for (let i = 0; i < 200000; i++) {
        var obj = CL_Counter(i);      
    }
    var clEnTime = new Date();

    var fnStTime = new Date();
    for (let i = 0; i < 200000; i++) {
        var obj1 = new CFN_Counter(i);      
    }
    var fnEnTime = new Date();

    var ptStTime = new Date();
    for (let i = 0; i < 200000; i++) {
        var obj2 = new PT_Counter(i);      
    }
    var ptEnTime = new Date();

    var cStTime = new Date();
    for (let i = 0; i < 200000; i++) {
        var obj3 = new Counter(i);      
    }
    var cEnTime = new Date();

    var clTime = clEnTime.getTime() - clStTime.getTime();
    var fnTime = fnEnTime.getTime() - fnStTime.getTime();
    var ptTime = ptEnTime.getTime() - ptStTime.getTime();
    var cTime = cEnTime.getTime() - cStTime.getTime();

    console.log("Closure: ", clTime);
    console.log("Function: ", fnTime);
    console.log("Prototype: ", ptTime);
    console.log("Class: ", cTime);
})();