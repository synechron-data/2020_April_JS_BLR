// import './1_Types/1_CustomType';
// import './1_Types/2_UsingPrototype';
// import './1_Types/3_Counter';
// import './1_Types/4_ES6_Class';
// import './1_Types/5_Compare';
// import './1_Types/6_ES5_Properties';
// import './1_Types/7_ES6_Properties';
// import './1_Types/8_StaticMembers';
// import './1_Types/9_ES5_Inheritance';
// import './1_Types/10_ES6_Inheritance';

// import './2_NewTypes/1_Symbols';
// import './2_NewTypes/2_Iterator_Generator';
// import './2_NewTypes/3_Generators';

// import './3_Proxy/demo1';
// import './3_Proxy/demo2';
// import './3_Proxy/demo3';

// import './4_Promise/1_Promise';

import './4_Promise/domHandlers';




