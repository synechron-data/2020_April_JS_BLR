function add(x, y) {
    // return x + y;
    throw new Error("Got Exception");
}

const handler = {
    // Trap - Whenever a Function is invoked
    apply: function (target, thisArg, argsList) {
        try {
            return target(argsList[0], argsList[1]);
        } catch (e) {
            console.error(e.message);
        }
    }
};

var proxyAdd = new Proxy(add, handler);
console.log("Result: ", proxyAdd(2, 3));

// try {
//     console.log("Result: ", add(2, 3));
// } catch (e) {
//     console.error(e.message);
// }
