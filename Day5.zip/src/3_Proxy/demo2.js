var person = { age: 28 };

let handler = {
    // Trap
    set: function (target, key, value) {
        if (key === 'age') {
            if (typeof value != "number" || Number.isNaN(value)) {
                throw ('Age must be a number');
            }
        }

        target[key] = value;
        return true;
    }
};

var personProxy = new Proxy(person, handler);

try {
    // person.age = "hi";
    // personProxy.age = 20;
    personProxy.age = "hi";
    console.log(person);
} catch (e) {
    console.error(e);
    console.log(person);
}

// handler.get
// handler.set
// handler.has
// handler.deleteProperty
// handler.construct
// handler.apply
// handler.deleteProperty
// handler.isExtensible



