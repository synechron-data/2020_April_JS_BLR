// 5 kinds of loops

// for      - Iterates a block of code specified number of time
// for/in   - Iterating the properties of an object
// for/of   - Iterating the values of an iterable (string and array) object (ES 2015)
// while    - Iterates a block of code specified condition is true
// do/while - Also Iterates a block of code specified condition is true

// for(statement1 (Initializing), statement2 (Condition), statement3 (After code block is executed)) {}

// for (let i = 0; i < 5; i++) {
//     console.log("i, ", i);
// }

// for (let i = 0, j = 10; i < 5; i++, j++) {
//     if (i === 2) {
//         // break;
//         continue;
//     }
//     console.log("i " + i + ", Output is " + j);
// }

// ------------------------------------------------------- Fon In

// var person = { fname: "Manish", lname: "Sharma", city: "Pune" };
// console.log(typeof person);

// for (const key in person) {
//     console.log(key);
//     console.log(person[key]);
// }

var numbers = [10, 20, 30, 40, 50, 60];

// for (let i = 0; i < numbers.length; i++) {
//     console.log(i + "\t" + numbers[i]);
// }

// for (const key in numbers) {
//     console.log(key + "\t" + numbers[key]);
// }

// ---------------------------------------------------------- For of

// for (const item of numbers) {
//     console.log(item);
// }

// -------------------------------------------------------- While

// while(condition){
//     // Code block
// }

// var i = 0;

// while (i < 5) {
//     console.log(i)
//     i++;
// }

// var i = 0;
// var i = 5;

// do {
//     console.log(i)
//     i++;
// } while (i < 5);

var person = { fname: "Manish", lname: "Sharma", city: "Pune" };

// for (const value of person) {
//     console.log(value);
// }

// ES 2017 (Object.values())
for (const value of Object.values(person)) {
    console.log(value);
}

for (const key of Object.keys(person)) {
    console.log(key);
}