// // var data = "asdasd23.5";
// var data = "23.5asdasd";

// // var a1 = data + 10;
// var a1 = 10 + data;
// console.log(a1);

// // var n1 = parseInt("10", 8);
// // console.log(n1);

// var a2 = parseInt(data) + 10;
// console.log(a2);

// var a3 = parseFloat(data) + 10;
// console.log(a3);

// var a4 = Number(data) + 10;
// console.log(a4);

// var obj = null;
// var obj;
// var obj = {};

// if ((obj === null) || (obj === undefined)) {
// if (!obj) {
//     console.log("Is Null or Undefined");
// } else {
//     console.log("Is Not Null or Undefined");
// }

// console.log(Boolean(1));
// console.log(Boolean(0));
// console.log(Boolean(-1));
// console.log(Boolean("ABC"));
// console.log(Boolean(""));
// console.log(Boolean(null));
// console.log(Boolean(undefined));

// console.log(true && true);
// console.log(true && false);

// console.log(true && "ABC");
// console.log(true && "ABC" || "XYZ");
// console.log(false && "ABC" || "XYZ");

{/* <h1 class={{isSelected() && "abc" || "xyz"}}></h1> */}

// T AND T - T
// T AND F - F
// F AND T - F
// F AND F - F

// T OR T - T
// T OR F - T
// F OR T - T 
// F OR F - F 

// false || "ABC" || "XYZ"
// false || true || true

// It is not recommended to use eval() because it is slow, it is also not secured
console.log(eval("5 + 5"));