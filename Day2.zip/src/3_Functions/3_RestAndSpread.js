// If I use ... on Lefthand side of EqualTo operator (Rest)
// If I use ... on Righthand side of EqualTo operator (Spread)

// ES2015 - Array Spread

// var arr1 = [1, 2, 3, 4, 5, 6, 7, 8, 9];
// console.log(arr1);
// console.log(typeof arr1);
// var arr2 = arr1;
// var arr2 = arr1.slice();
// var arr2 = [...arr1];

// arr2[0] = 1000;

// console.log("Array 1", arr1);
// console.log("Array 2", arr2);

// var arr1 = [1, 2, 3, 4];
// var arr2 = [5, 6, 7, 8];
// // var arr3 = [].concat(arr1, arr2);
// var arr3 = [...arr1, ...arr2];

// console.log("Array 1", arr1);
// console.log("Array 2", arr2);
// console.log("Array 3", arr3);

// ------------------------------------------- Array Destructuring

var arr = [10, 20, 30, 40, 50, 60, 70, 80, 90];

// var x = arr[0];
// var y = arr[1];

// var [x, , y] = arr;
// console.log(`x = ${x}, y = ${y}`);

var [x, y, ...z] = arr;
console.log(`x = ${x}, y = ${y}, z = ${z}`);