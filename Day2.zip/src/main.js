// import "./1_Operators/1_Comparision";
// import "./1_Operators/2_Convertion";

// import "./2_CertainConditions/3_Loops";
// import "./2_CertainConditions/4_Statements";

// import './3_Functions/1_FnCreation';
// import './3_Functions/2_FnParameters';
import './3_Functions/3_RestAndSpread';



// ------------------------------------------ Day 1 Doubts 
// var i = 10;

// function test() {
//     var i = 100;
//     console.log("Inside Fn: ", i);
// }

// console.log("Before Loop, Outside Fn: ", i);

// // for (let i = 0; i < 5; i++) {
// //     console.log("Inside Loop: ", i);
// // }

// if (true) {
//     // var i = 1000;
//     let i = 1000;
//     console.log("Inside if: ", i);
// }

// test();
// console.log("After Loop, Outside Fn: ", i);
